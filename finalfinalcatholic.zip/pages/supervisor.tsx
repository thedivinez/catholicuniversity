import React from 'react'

const Supervisor = () => {
    return (
        <div>Supervisor</div>
    )
}

export default Supervisor